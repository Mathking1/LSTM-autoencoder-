## Project proposal form

Please provide the information requested in the following form. Try provide concise and informative answers.

**1. What is your project title?**

**2. What is the problem that you want to solve?**

**3. What deep learning methodologies do you plan to use in your project?**

**4. What dataset will you use? Provide information about the dataset, and a URL for the dataset if available. Briefly discuss suitability of the dataset for your problem.**

**5. List key references (e.g. research papers) that your project will be based on?**

**Please indicate whether your project proposal is ready for review (Yes/No):**

## Feedback (to be provided by the course lecturer)

[FP, Mar 28]. Hello 1-3-2-2, thanks for your proposal. I approve this, and I have a couple of suggestions for you. 

First, prepare a thorough literature review where you state well who has done what and identify well your contributions. With a very common topic like stock price prediction it is easy to get lost in the literature, so you need to take particular care to present what are the original contributions of your work.

Secondly, in your proposal I see only one model (composed of different parts). Please make sure to compare a few different models to see which one performs best. As comparison you can also use non deep learning models, but of course the focus of the project should be on DL.

PS: you have a typo in the project title.
