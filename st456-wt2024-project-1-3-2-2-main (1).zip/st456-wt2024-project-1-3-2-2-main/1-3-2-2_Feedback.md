## Project group 1-3-2-2

## Title: S&P 500 Predictive Analytics through LSTM-AE and Wavelet-Based Noise Reduction: A Deep Learning Strategy to Financial Time Series Analysis

## Candidate numbers: 34148, 30458, 28041, 23771

### Introduction (Abstract, Intro and Related Work) 

The part where you introduce the features used in stock price prediction would benefit from more information: which technical indicators and textual data are you talking about? You should also be more specific about what are your contributions against the literature, since for example Hsieh et al. (2011) also do Wavelet + RNN and Lee et al. (2021) do Wavelet + LSTM.

### Solution method (Architecture and Training Methods)

A reference for the wavelet theory part would be important. Regarding parameter choices, what does thresholding mean in formula 1? Also, you could have shown some experiments with different parameters settings to corroborate your choices.

LSTM AE: you mention the compressed representation c, but that does not appear in the formulas. What does UAV mean? Unmanned aerial vehicle is a very different application from what you are doing. Similar comment as before on the choice of time steps: on this you could have done a grid-search for example. 

In figure 1, what do L1, D1, L2… stand for?

The LSTM part is very general for a paper. It is not necessary to explain all of this in such a general form or mentioning applications that are far away from yours. You could have used the space to be more specific about your model (to which you dedicate a really short paragraph) which is not conclusive. After reading section 2, in fact, we still don’t know what is the structure of your model.

### Choice and description of data (Numerical Results) 

The description of the data is fine, together with the description of your train\validation\test split (here we think there’s a typo: not figure 9 but 2). Some exploratory data analysis would have been nice.

### Numerical evaluation (rest of Numerical Results and part of Interpretation) 

Is the choice of the correlation coefficient a good one for your problem? R measures the linear correlation, are you sure that this is a good idea in a setting where most probably variables have non-linear relationships?

Which data do you take for hyperparameter tuning?

### Conclusion (part of Interpretation and Conclusion) 

You mention that LSTM is a more complex structure and therefore better suited than GRU: GRU were actually introduced later to simplify but overperform LSTM.

The result and conclusion sections are lacking in comments. Things you could and should have addressed are for example what is the effect of the covariates on the prediction. You mention you meticulously choose them, but there is absolutely no mention to their importance later on. 

Some comments that you make act as hypothesis, but you do not really explore them (for example the role of AE). Also, you do not comment the prediction figures in the appendix. There are some interesting trends going on there, for example that some models towards the end of the time window perform extremely bad (the predictions go up when the true price goes down or vice versa): why is that? Even in your best model WLAE-LSTM you can observe this striking behaviour. There could have also been some interesting comments about the fact that you had COVID-19 years in the test sets, and your models displayed some higher errors (this is expected, but you should have at least noticed).

### Presentation 

In terms of notation, in a paper you would avoid using the coding name of functions or parameters (for example time_steps), unless it is extremely necessary.
The report gives the feeling of staying on the surface. You could have structured things by going much deeper into your models architecture or analysing your results.


### Code implementation 

The code could have been complemented with a ReadMe file to understand its structure. In some parts of the notebooks there are quite a few comments, while in others less. Some prints are unnecessary and very long and full of warnings.

**Final mark: 53**
